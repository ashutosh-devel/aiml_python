# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 15:40:15 2023

@author: Kannan
"""

import sys

from PyQt5.QtWidgets import (
          QApplication, QMainWindow, QMessageBox)

from helloworldwithpushBUI import Ui_MainWindow


class Window(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.connectSignalsSlots()
        
    def connectSignalsSlots(self):
        self.ui.okpushButton.clicked.connect(self.okPbutton_actionperformed)
        self.ui.cancelpushButton.clicked.connect(self.cancelPbutton_actionperformed)

    def okPbutton_actionperformed(self,event):
        result = QMessageBox.question(self,
                      "Confirm Exit...",
                      "Are you sure you want to exit ?",
                      QMessageBox.Yes| QMessageBox.No)
        # self.closeEvent()

        if result == QMessageBox.Yes:
            self.close()        
        
    def cancelPbutton_actionperformed(self,event):
        self.close()
        
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = Window()
    win.show()
    sys.exit(app.exec())