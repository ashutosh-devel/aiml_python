# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 15:40:15 2023

@author: Kannan
"""

import sys

from PyQt5 import QtCore, QtGui
from PyQt5.QtCore import Qt

from ImageDisplayUI import Ui_MainWindow
import matplotlib.pyplot as plt
import pyqtgraph as pg
import numpy as np

class ControlWindow(QtGui.QMainWindow):
    def closeEvent(self,event):
        result = QtGui.QMessageBox.question(self,
                      "Confirm Exit...",
                      "Are you sure you want to exit ?",
                      QtGui.QMessageBox.Yes| QtGui.QMessageBox.No)
        event.ignore()

        if result == QtGui.QMessageBox.Yes:
            event.accept()

class MyCrosshairOverlay(pg.CrosshairROI):
    def __init__(self,pos=None, size=None,**kargs):
        self._shape=None
        pg.ROI.__init__(self,pos,size,**kargs)
        self.sigRegionChanged.connect(self.invalidate)
        self.aspectLocked

class POINTID(object):
    def __init__(self):
        self.ui = None
        self.app = None
        self.MainWindow = None
        self.image_clickedX = -1
        self.image_clickedY = -1 
        self.selectedRow = -1
        self.cross_hair=None 
        self.pen = None
        self.pen_size = 30    
        self.text_object=[]


    def initComponents(self):
        self.app = QtGui.QApplication(sys.argv)
        self.MainWindow = ControlWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.MainWindow)
        self.ui.addpushButton.clicked.connect(self.addPoint_actionperformed)
        self.ui.removepushButton.clicked.connect(self.removePoint_actionperformed)    
        self.ui.exitpushButton.clicked.connect(self.exitPbutton_actionperformed)    
        self.ui.cancelpushButton.clicked.connect(self.cancelPbutton_actionperformed)    
#        self.ui.savepushButton.clicked.connect(self.save_actionperformed)            
        self.ui.graphicsView.getImageItem().mouseClickEvent = self.image_mousepoint_click 
        self.ui.tableWidget.verticalHeader().sectionClicked.connect(self.row_selected)
        self.ui.graphicsView.ui.menuBtn.hide()
        self.ui.graphicsView.ui.roiBtn.hide()
        self.current_pen = QtGui.QPen(QtCore.Qt.red,0.1)
        self.current_pen.setWidthF(10)   
        self.accepted_pen = QtGui.QPen(QtCore.Qt.blue,0.1)
        self.accepted_pen.setWidthF(10)           
        self.ui.tableWidget.verticalHeader().sectionClicked.connect(self.row_selected)


    def image_mousepoint_click(self,event):
        event.accept()
        pos=event.pos()
        self.image_clickedX = round(pos.x(),2)
        self.image_clickedY = round(pos.y(),2)
        pid.ui.yvaluelineEdit.setText(str(self.image_clickedY))
        pid.ui.xvaluelineEdit.setText(str(self.image_clickedX))
        
        if self.cross_hair is None:
            self.cross_hair=MyCrosshairOverlay(pos=(int(pos.x()),int(pos.y())),size=self.pen_size,pen=self.current_pen,movable=False,angle=45)                
            self.ui.graphicsView.getView().addItem(self.cross_hair)            
        else:
            self.ui.graphicsView.getView().removeItem(self.cross_hair)
            self.cross_hair=MyCrosshairOverlay(pos=(int(pos.x()),int(pos.y())),size=self.pen_size,pen=self.current_pen,movable=False,angle=45)                
            self.ui.graphicsView.getView().addItem(self.cross_hair)                         
        
        
    def addPoint_actionperformed(self):

        if self.image_clickedX != -1:
            self.ui.graphicsView.getView().removeItem(self.cross_hair)
            self.cross_hair=None

            cross_hair=MyCrosshairOverlay(pos=(int(self.image_clickedX),int(self.image_clickedY)),size=self.pen_size,pen=self.accepted_pen,movable=False,angle=45)                
            self.ui.graphicsView.getView().addItem(cross_hair)   
            self.text_object.append(cross_hair)           
            

        rowPosition = self.ui.tableWidget.rowCount()
        self.ui.tableWidget.insertRow(rowPosition)
        index=-1
    
        index+=1
        item=QtGui.QTableWidgetItem(str(self.image_clickedX))
        item.setFlags(Qt.ItemIsEnabled)            
        self.ui.tableWidget.setItem(rowPosition,index,item) 
            
        index+=1        
        item=QtGui.QTableWidgetItem(str(self.image_clickedY))
        item.setFlags(Qt.ItemIsEnabled)
        self.ui.tableWidget.setItem(rowPosition,index,item)

        index+=1
        self.ui.tableWidget.setItem(rowPosition,index,QtGui.QTableWidgetItem(str('1')))        

        self.image_clickedX = -1 
            
    def removePoint_actionperformed(self):
        if self.selectedRow != -1:
            self.ui.tableWidget.removeRow(self.selectedRow)
            if len(self.text_object) > 0 :
                self.ui.graphicsView.getView().removeItem(self.text_object[self.selectedRow])                        
                self.text_object.remove(self.text_object[self.selectedRow])
            self.selectedRow=-1
        else:
            QtGui.QMessageBox.critical(self.MainWindow,
            "Error",
            "Please click on desired row header to remove",
            QtGui.QMessageBox.Ok)


    def set_image(self,data):
        data=np.flipud(data)
        data=np.rot90(data,3)         
        self.ui.graphicsView.setImage(data)

    def showWindow(self):
        self.MainWindow.show()
        self.app.exec_()
        
    def row_selected(self,clickedIndex):
        self.selectedRow = clickedIndex        

    def exitPbutton_actionperformed(self):
        QtGui.QMessageBox.about(self.MainWindow,
                      "Confirm Exit...",
                      "Are you sure you want to exit ?",
                      )
        sys.exit(self.app.exec_())
        
         
    def cancelPbutton_actionperformed(self):
        QtGui.QMessageBox.about(self.MainWindow,"Message","Cancelling Process")
        sys.exit(self.app.exec_())
                  
        
if __name__ == "__main__":
    
    
    pid=POINTID()
    pid.initComponents()

    image_filename=sys.argv[1]
    image=plt.imread(image_filename)
    pid.set_image(image)
    pid.showWindow()
