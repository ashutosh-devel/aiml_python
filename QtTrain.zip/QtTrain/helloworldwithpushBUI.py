# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'helloworldwithpushB.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.hellolabel = QtWidgets.QLabel(self.centralwidget)
        self.hellolabel.setGeometry(QtCore.QRect(320, 110, 221, 141))
        font = QtGui.QFont()
        font.setPointSize(24)
        self.hellolabel.setFont(font)
        self.hellolabel.setTextFormat(QtCore.Qt.RichText)
        self.hellolabel.setObjectName("hellolabel")
        self.okpushButton = QtWidgets.QPushButton(self.centralwidget)
        self.okpushButton.setGeometry(QtCore.QRect(200, 320, 75, 23))
        self.okpushButton.setObjectName("okpushButton")
        self.cancelpushButton = QtWidgets.QPushButton(self.centralwidget)
        self.cancelpushButton.setGeometry(QtCore.QRect(370, 320, 75, 23))
        self.cancelpushButton.setObjectName("cancelpushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.hellolabel.setText(_translate("MainWindow", "Hello World"))
        self.okpushButton.setText(_translate("MainWindow", "OK"))
        self.cancelpushButton.setText(_translate("MainWindow", "Cancel"))

